#Radosław Siwiec
#APU Laboratorium 4
#Wariant: 3

install.packages("C50")
library("C50")

setwd("g:/ATH/! Informatyka/I sem/APU - Analiza procesów uczenia/Lab4/")
dane <- read.csv('aparaty2.csv')

dane$Oceny <- factor(dane$Oceny)
head(dane)

treeModel <- C5.0(x=dane[,-6], y=dane$Oceny)

treeModel
summary(treeModel)
plot(treeModel)
