#Radosław Siwiec
#APU Laboratorium 3
#Wariant: 3

#Zadanie1

library("neuralnet")

normalize <- function(x) 
{
  return ((x - min(x)) / (max(x) - min(x)))
}

input <- as.data.frame(runif(100, min = 1, max = 16))
output <- exp(input^0.5)

trainingData <- cbind(input, output)
colnames(trainingData) <- c("Input", "Output")

datanorm <- as.data.frame(lapply(trainingData, normalize))

net.price <- neuralnet(Output~Input, datanorm, hidden = c(5, 3), threshold = 0.01)

plot(net.price)


#Zadanie2
setwd("g:/ATH/! Informatyka/I sem/APU - Analiza procesów uczenia/Lab3")
aparaty <- read.csv("aparaty.csv")

normalize <- function(x) 
{
  return ((x - min(x)) / (max(x) - min(x)))
}

cena <- aparaty$Cena

aparaty <- aparaty[,-8]
aparaty <- aparaty[,-5]
aparaty <- aparaty[,-1]
aparaty

aparaty <- cbind(aparaty, cena)
aparaty

aparaty[,2:6] <- as.data.frame(lapply(aparaty[,2:6], normalize))

net.price <- neuralnet(cena~Rozdzielczosc+Zakres.czulosci+Liczba.opini+Oceny,
                       aparaty, hidden = c(6,4,4), threshold = 0.01)

plot(net.price, cex=0.8)
