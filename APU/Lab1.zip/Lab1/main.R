#Lab1 wariant 3

#a
a <- 5/4^3
b <- a*2
a<b

#b
help("min")

#c
a <- c(50:75)
mean(a^2)

#d
apropos("min", mode = "function")

#e
setwd("g:/ATH/! Informatyka/I sem/APU - Analiza procesów uczenia/Lab1")
a <- "aparat z wymienną optyką"
save(a, file = "a.RData")
remove(a)
ls()
load("a.RData")
ls()

#f
install.packages("gridExtra")
library(gridExtra)
library(grid)

help(package="gridExtra")

d <- head(Seatbelts, 10)
g <- tableGrob(d)
grid.newpage()
grid.draw(g)

#g Stw´orz wektor zawieraja˛cy cia˛g liczb 1000, 995,990,. . . 800
w <- c(1000, 995, 990:800)

#h Stw´orz wektora a z liczbami od 29 do 5 oraz wektor b z liczbami
#od 21 do 33. Utw´orz nowy wektory d be˛da˛cy po la˛czeniem wektora
#b i a (w takiej kolejno´sci). Wy´swietl go
a <- c(29:5)
b <- c(21:33)
d <- c(b, a)
d

#(i) Stw´orz wektor nazwa zawieraja˛cy nazwy 10 aparat´ow z wyminna˛
#optyka˛. Potem stw´orz wektory rozdzielczo´s´c, zakres_czu lo´sci,
#cena, liczba_opinii zawieraja˛ce kolejno dane 10 aparat´ow. Naste˛pnie
#stw´orz ramke˛ danych aparaty z lo˙zona˛ z wektor´ow nazwa, rozdzielczo´s´c, zakres_czu lo´sci, cena, liczba_opinii. 
#Wylicz ´srednia˛ cene˛ aparat´ow.

nazwa <- c("Aparat1", "Aparat2", "Aparat3", "Aparat4", "Aparat5", 
           "Aparat6", "Aparat7", "Aparat8","Aparat9","Aparat10")

# w megapikselach
roz <- c(8, 5, 10, 12, 34, 20, 14, 8, 10, 50) 
zak <- c(25600, 3200, 40000, 25600, 6400, 25600, 3200, 6400, 25600, 40000)
cena <- c(2500, 1000, 5000, 3200, 1200, 3400, 900, 1300, 3120, 5400)
opini <- c(12, 3, 2, 3, 6, 56, 34, 6, 23, 5)

aparaty <- data.frame(Nazwa = nazwa, Rozdzielczosc = roz,"Zakres czulosci" =  zak, Cena = cena, "Liczba opini" =  opini)
srcena <- mean(aparaty$Cena);

#(j) Do stworzonej w poprzednim zadaniu ramki danych aparat´ow dodaj wpis zawieraja˛cy dane nowego aparatu. Wylicz ´srednia˛ ceny
#ponownie.

newrow <- data.frame(Nazwa = "AparatX", Rozdzielczosc = 30,"Zakres czulosci" =  25600, Cena = 3200, "Liczba opini" =  5)

aparaty <- rbind(aparaty, newrow)
srcena <- mean(aparaty$Cena)

#(k) Korzystaja˛c z ramki danych aparaty dodaj nowa˛ kolumne˛ okre´slaja˛c
#ocene˛ klient´ow. Wpisz do kolumny odpowiednio oceny w skali od
#0 do 5 krok 0.5. Dodana kolumna powinna sie˛ automatycznie
#przekonwertowa´c do cech jako´sciowych (tzw. factors). Wylicz
#´srednia˛ ceny ka˙zdej oceny.

aparaty$Oceny <- c(1, 2, 3, 4, 5, 5, 4, 3, 2, 1, 4.5)

aggregate(aparaty$Cena, list(aparaty$Oceny), mean)

#(l) Do ramki danych aparaty dodaj kolejne 4 aparaty. Narysuj na
#wykresie s lupkowym liczebno´s´c reprezentant´ow ka˙zdej z ocen klient´ow.

nazwa <- c("nowyAparat1", "nowyAparat2", "nowyAparat3", "nowyAparat4")
roz <- c(8, 5, 10, 12) 
zak <- c(25600, 3200, 40000, 25600)
cena <- c(2500, 1000, 5000, 3200)
opini <- c(134, 32, 23, 43)
oceny <- c(3, 3.5, 4.5, 5)

newrow <-  data.frame(Nazwa = nazwa, Rozdzielczosc = roz,"Zakres czulosci" =  zak, Cena = cena, "Liczba opini" =  opini, Oceny = oceny)
aparaty <- rbind(aparaty, newrow)

#dane <- aggregate(aparaty$Liczba.opini, list(aparaty$Oceny), sum)
#dane <- aggregate(aparaty$Liczba.opini, list(aparaty$Oceny), length)
#barplot(dane, main = 'Liczba reprezentantów kazdej z ocen')

dane <- table(aparaty$Oceny)
barplot(dane, main = 'Liczba reprezentantów kazdej z ocen')

#(m) Wykorzystujac ramke˛ danych aparaty poka˙z procentowy udzial
#ka˙zdej oceny przy pomocy wykresu ko lowego oraz wachlarzowego.

#wykres kolowy
labels <- round(dane / length(aparaty$Oceny) * 100, 1)
labels <- paste(labels, "%", sep="")

pie(dane, labels = labels, radius = 1, col = rainbow(length(dane)))
legend(1.5, 1, names(dane), cex=0.9, fill=rainbow(length(dane)))

#wykres wachlarzowy
install.packages("plotrix")
library(plotrix)
percent <- dane / length(aparaty$Oceny)
fan.plot(percent, labels = names(percent), main = "Procentowy udzial oceny")
legend(1.1, 1, names(percent), cex=0.9, fill=rainbow(length(percent)))

#(n) Do ramki danych aparaty dodaj nowa˛ kolumne˛ status_opinii z
#warto´sciami: “nie ma”, “mniej 50 opinii”, "50-100 opinii", "wie˛cej
#100 opinii" w zale˙zno´sci od liczby opinii. Zamie´n dodana˛ kolumne˛
#na cechy jako´sciowe. Naste˛pnie przy pomocy wykresu ko lowego
#wyrysuj procentowy udzia l aparat´ow o konkretnym statusie opinii.

new_col <- ifelse(aparaty$Liczba.opini > 100,'więcej niż 100 opinii',
                  ifelse(aparaty$Liczba.opini >= 50, '50-100 opinii',
                         ifelse(aparaty$Liczba.opini > 0, 'mniej 50 opinii', 'nie ma')))

aparaty['status_opinii'] <- factor(new_col)

#wykres kolowy
pie(table(aparaty$status_opinii), radius = 0.9, col = rainbow(length(aparaty$status_opinii)))

#(o) Wykorzystujac ramke˛ danych aparaty stworz zdanie o ka˙zdym z
#aparatow postaci: nazwa + ” ma ocene˛ klient´ow ” + ocena_klient´ow
#+ ” bo ma liczbe˛ opinii” + liczba_opinii. Plus oznacza konkatenacje lancuchow i warto´sci.

for (i in 1:length(aparaty$Nazwa))
{
  print(paste(aparaty$Nazwa[i]," posiada ocenę klientów: ", 
              aparaty$Oceny[i], " oraz liczbę opinii: ", 
              aparaty$Liczba.opini[i]))
}


#(p) Zachowa ramke˛ danych w pliku .csv. Za ladowa´c ramke˛ danych z
#pliku .csv
#Dane (15 aparat´ow) pobra´c ze strony http://www.euro.com.pl

write.csv(aparaty, 'aparaty.csv')
dane <- read.csv('aparaty.csv')

