#Radosław Siwiec
#APU Laboratorium 4
#Wariant: 3

#Zadanie2
install.packages("mlr")
install.packages("rFerns")
install.packages("randomForestSRC")
library("mlr")
library("rFerns")
library("randomForestSRC")

setwd("g:/ATH/! Informatyka/I sem/APU - Analiza procesów uczenia/Lab5/Zad2")
aparaty <- read.csv("aparaty.csv")

aparaty$ocena <- factor(aparaty$ocena)

zad = makeClassifTask(id = deparse(substitute(aparaty)), aparaty, "ocena",
                  weights = NULL, blocking = NULL, coordinates = NULL,
                  positive = NA_character_, fixup.data = "warn", check.data = TRUE)

ponowneProbkow = makeResampleDesc(method = "CV", iters = 2, stratify = TRUE)

metody <- makeLearners(c("rpart", "C50","rFerns",
                                 "randomForestSRC"), type = "classif")
#porównywanie metod
porownanieMetod <- benchmark(learners = metody,
                                      tasks = zad,
                                      resampling = ponowneProbkow)

porownanieMetod

plotBMRBoxplots(porownanieMetod, measure = mmce,
                order.lrn = getBMRLearnerIds(porownanieMetod))
plotBMRSummary(porownanieMetod)
plotBMRRanksAsBarChart(porownanieMetod, pos = "dodge",
                       order.lrn = getBMRLearnerIds(porownanieMetod))
