#Radosław Siwiec
#APU Laboratorium 5
#Wariant: 3

#Zadanie1
install.packages("C50")
install.packages("MASS")
library("C50")
library("MASS")

data(mtcars)
head(mtcars)

mtcars$carb <- factor(mtcars$carb)

drzewoDecyzyjne <- C5.0(x=mtcars[,-11], y=mtcars$carb)

summary(drzewoDecyzyjne)
drzewoDecyzyjne
plot(drzewoDecyzyjne)
